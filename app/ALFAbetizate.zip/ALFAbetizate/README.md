Application that makes use of interactive activities and that combine audio and voice recognition technology so that illiterate people have the opportunity to learn how to read and write.
